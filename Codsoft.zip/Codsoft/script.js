// Menu and navbar interactions
let menu = document.querySelector('#menu');
let navbar = document.querySelector('.navbar');
let header = document.querySelector('.navigation');

// Check if the elements exist
if (menu && navbar && header) {
    menu.addEventListener('click', () => {
        menu.classList.toggle('fa-times');
        navbar.classList.toggle('active');
    });

    window.onscroll = () => {
        menu.classList.remove('fa-times');
        navbar.classList.remove('active');

        if (window.scrollY > 150) {
            header.classList.add('active');
        } else {
            header.classList.remove('active');
        }
    }
} else {
    console.error("Menu, navbar, or header elements not found!");
}

// Countdown timer
let countDate = new Date('November 15, 2024 00:00:00').getTime(); // Ensure the date is in the future

function CountDown() {
    let now = new Date().getTime();
    let gap = countDate - now;

    let second = 1000;
    let minute = second * 60;
    let hour = minute * 60;
    let day = hour * 24;

    let d = Math.floor(gap / day);
    let h = Math.floor((gap % day) / hour);
    let m = Math.floor((gap % hour) / minute);
    let s = Math.floor((gap % minute) / second);

    // Check if the countdown elements exist
    if (document.getElementById('day') && document.getElementById('hour') &&
        document.getElementById('minute') && document.getElementById('second')) {
        document.getElementById('day').innerText = d;
        document.getElementById('hour').innerText = h;
        document.getElementById('minute').innerText = m;
        document.getElementById('second').innerText = s;
    } else {
        console.error("Countdown elements not found!");
    }
}

// Call the function initially to set the countdown immediately
CountDown();

// Update the countdown every second
setInterval(CountDown, 1000);
